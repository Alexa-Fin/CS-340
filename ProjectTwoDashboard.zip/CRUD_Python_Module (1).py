# Example Python Code to Insert a Document 

from pymongo import MongoClient
from pymongo.errors import PyMongoError

class AnimalShelter(object):
    """ CRUD operations for Animal collection in MongoDB """

    def __init__(self, username='aacuser', password='password', host='localhost', port=27017):
        try:
            uri = f"mongodb://{username}:{password}@{host}:{port}/admin"
            self.client = MongoClient(uri)
            self.database = self.client['aac']
            self.collection = self.database['animals']
        except PyMongoError as e:
            print(f"Connection error: {e}")
            self.collection = None

    def create(self, data):
        # Inserts a document into the collection. Returns True if successful.
        if self.collection is None:
            return False
        try:
            result = self.collection.insert_one(data)
            return result.acknowledged
        except PyMongoError as e:
            print(f"Insertion error: {e}")
            return False

    def read(self, query):
        # Queries documents using the provided key/value pair.
        # Returns list of matching documents, or an empty list if none found.
        if self.collection is None:
            return []
        try:
            cursor = self.collection.find(query)
            return list(cursor)
        except PyMongoError as e:
            print(f"Query error: {e}")
            return []

    def update(self, query, new_values):
        # Updates documents matching the query with new_values. Returns the number of documents modified.
        if self.collection is None:
            return 0
        try:
            result = self.collection.update_many(query, {'$set': new_values})
            return result.modified_count
        except PyMongoError as e:
            print(f"Update error: {e}")
            return 0

    def delete(self, query):
        # Deletes document(s) matching the query. Returns the number of documents deleted.
        if self.collection is None:
            return 0
        try:
            result = self.collection.delete_many(query)
            return result.deleted_count
        except PyMongoError as e:
            print(f"Delete error: {e}")
            return 0
